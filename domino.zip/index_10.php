<html>
    <head>
        <script src="http://code.jquery.com/jquery-2.1.1.js" type="text/javascript"></script>
        <script>
            function dibujaTablero(rows, cols)
            {
                var valor = rows * cols;
                document.open("text/plain");
                for (var i = 0; i < rows; i++)
                {
                    document.write("<tr>");
                    for (var j = 0; j < cols; j++)
                    {
                        var pos = (i * cols) + j;
                        document.write("<td class=" + pos + " id=" + i + "_" + j + " style=\"border: 1 px solid black; width:30px; height: 15px; font-size: 30px;\"></td>");
                    }
                    document.write("</tr>");
                }
                document.close();
            }

            function pintartablero() {
                console.log('pintar tablero');
                $.ajax({
                    url: "/domino/domino.php",
                    dataType: 'json',
                    data: {posicionesDelTablero: 1},
                    success: function(data)
                    {
                        for (var i = 0; i < data.length; i++)

                        {
                            var x = data[i].posicion_y;
                            var y = data[i].posicion_x;
                            var ficha = data[i].numero;
                            if (ficha != 7)
                            {
                                $('#' + x + "_" + y).html("<img src= './fichas/" + ficha + ".jpg'>");
                            }
                        }
                    }
                });
            }
            function Tirar(id, key)
            {
                $.ajax({
                    url: "/domino/domino.php",
                    dataType: 'json',
                    data: {tiraFicha: id, key: key},
                    success: function(data) {
                        console.log("pintandooooo");
                        pintartablero();
//                        console.log("entro a tirar");
//                        var longutid = data.length;
//                        if (longutid === 0)
//                        {
//                            pintartablero();
//                        } else
//                        {
//                            pintartablero();
//                        }

                    }
                });
            }
            function Jugar(id) {
                console.log("iddddddddddddd" + id);
                $.ajax({
                    url: "/domino/domino.php",
                    dataType: 'json',
                    data: {obtenLugaresPermitidos: id},
                    success: function(data) {
                        console.log("entro a permitidos");
                        var longutid = data.length;
                        console.log(longutid);
                        if (longutid === 0)
                        {
                            pintartablero();
                        } else
                        {
                            for (var key in data)
                            {
                                console.log('key' + " " + key);
                                console.log('data' + " " + data[key]);
                                break;
                            }
                            Tirar(id, key);

                        }

                    }
                });
                console.log($('#' + id).attr('class'));
//                $('#13_13').append("<a style=\"text-decoration:none;\">H</a>");
//            pos.appendChild("<a style=\"text-decoration:none;\">&nbsp;&nbsp;H</a>");

            }

            function asignarFichas()
            {

                var fichas1 = "<tr id='tr_fichas'>";
                var fichas2 = "<tr id='tr_fichas'>";
                $.ajax({
                    url: "/domino/domino.php",
                    dataType: 'json',
                    data: {obtenFichasDeUsuario: 1},
                    success: function(data) {
                        for (var i = 0; i < 6; i++)
                        {
                            var foto1 = data[i].numero1;
                            var foto2 = data[i].numero2;
                            var id = data[i].id;
                            fichas1 = fichas1 + "<td class=" + foto1 + " id= 'sdsd' style=\"border: 1 px solid black; width:30px; height: 15px; font-size: 30px;\"><a id=" + id + " class " + foto1 + " style=\"text-decoration:none;\" onclick=\"Jugar(this.id)\" href=\"#\"><img src= './fichas/" + foto1 + ".jpg'></a></td>";
                            fichas2 = fichas2 + "<td class=" + foto2 + " id= 'sdsd' style=\"border: 1 px solid black; width:30px; height: 15px; font-size: 30px;\"><a id=" + id + " class " + foto2 + " style=\"text-decoration:none;\" onclick=\"Jugar(this.id)\" href=\"#\"><img src= './fichas/" + foto2 + ".jpg'></a></td>";
                        }
                        var result1 = fichas1 + "</tr>";
                        var result2 = fichas2 + "</tr>";
                        $('#posFichas').append(result1);
                        $('#posFichas').append(result2);

                    }

                });
                $('#obtener').attr("disabled", true);

            }
            function Turno() {
                historial();
            }
            function historial()
            {
                $.post("/domino/domino.php", {obtenFichasDeUsuario: 1}).done(function(data) {
                    for (var i = 0; i < data.length; i++)
                    {
                        var ficha1 = data[i]['numero1'];
                        var ficha1 = data[i]['numero1'];
                    }
                });

            }

        </script>
    </head>
    <body onload="setInterval(historial(), 5000)">
        <table  border=1>
            <tr> 
                <td> 
                    <table style="border: 1px solid black;"  align=center  bgcolor= white>
                        <script language=javascript>
                            new dibujaTablero(21, 31);
                        </script>
                    </table>
                    <div id="fichas" style="border:2px solid #d0d0d0;">
                        <div class="cont_tabla" style="margin-left: 330px;">
                            <table id="posFichas" border=1>

                            </table>
                        </div>
                    </div>
                    <button id="obtener" onclick="asignarFichas()" >ObtenerFichas</button>
                </td>
            </tr>
        </table>
    </body>
</html>