<?php

$conn = mysql_connect('localhost', 'root', 'dominic')
    or die('No se pudo conectar: ' . mysql_error());
mysql_select_db('domino',$conn) or die('No se pudo seleccionar la base de datos');

function ExQy($sql){
    $conn = mysql_connect('localhost', 'root', 'dominic')
    or die('No se pudo conectar: ' . mysql_error());
    mysql_select_db('domino',$conn) or die('No se pudo seleccionar la base de datos');
    $resultado = mysql_query($sql, $conn);
    
    $resultados = array();
    while ($row       = mysql_fetch_assoc($resultado)) {
    	$resultados[] = $row;
    }
    return $resultados;
}
function insert($sql){
    $conn = mysql_connect('localhost', 'root', 'dominic')
    or die('No se pudo conectar: ' . mysql_error());
    mysql_select_db('domino',$conn) or die('No se pudo seleccionar la base de datos');
    $resultado = mysql_query($sql, $conn);
    return $resultado;
}

?>