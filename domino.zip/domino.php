<?php
    include('conexion.php');
    
    session_start();

    if($_REQUEST){
        foreach ($_REQUEST as $key => $value) {
            $$key = $value;
        }

    }
    if($PartidaNueva == '1'){
        PartidaNueva((int)$numeroJugadores);
        exit;
    }
    if($PartidaDisponible == '1'){
        $disp = PartidaDisponible();
        echo $disp;
        exit;
    }
    if($obtenFichasDeUsuario == '1'){
        $disp = obtenFichasDeUsuario($_SESSION['idPartida'],$_SESSION['idUsuario']);
        header('Content-type: application/json');
        echo $disp;
        exit;
    }
    if($crearTablero == '1'){
        $disp = crearTablero(23);
        echo $disp;
        exit;
    }

    if($AsignaFichas == '1'){
            $disp = AsignaFichas($_SESSION['idPartida'],$_SESSION['idUsuario']);
            echo $disp;
            exit;
    }
    if($posicionesDelTablero == '1'){
        header('Content-type: application/json');
            $disp = posicionesDelTablero();
            echo $disp;
            exit;
    }
    if($obtenLugaresPermitidos > 0){
        header('Content-type: application/json');
            $disp = obtenLugaresPermitidos($_SESSION['idPartida'],$_SESSION['idUsuario'],$obtenLugaresPermitidos);
            echo $disp;
            exit;
    }
    if($obtenLugaresDisponibles ==1){
        header('Content-type: application/json');
            $disp = obtenLugaresDisponibles($_SESSION['idPartida']);
            echo json_encode($disp);
            exit;
    }

    if($esMiTurno ==1){
            $disp = esMiTurno($_SESSION['idUsuario'],$_SESSION['idPartida']);
            echo $disp;
            exit;
    }
    if($borrarPartida ==1){
            $disp = borrarPartida();
            echo $disp;
            exit;
    }
    if($tiraFicha >0){

            $disp = tiraFicha($key,$_SESSION['idPartida'],$_SESSION['idUsuario'],$tiraFicha);
            //function tiraFicha($posicionTableroId, $partida_id, $usuario_id, $partida_ficha_id)
            echo $disp;
            exit;
    }

    function Usuarios(){

    }

    function PartidaNueva($numeroJugadores){
        $sql = "UPDATE partidas SET Estado = 0";
        insert($sql);
        $sql = "INSERT INTO  partidas (fecha ,numero_jugadores,Estado) VALUES ( NOW(),  $numeroJugadores,1)";
        insert($sql);
        echo "ok";
    }
    function PartidaDisponible(){
        $sql="SELECT * FROM partidas WHERE Estado != 0";
        $disponible = ExQy($sql);
        $disponiblePartida = NULL;
        foreach ($disponible as $data) {
            $disponiblePartida = $data['id'];   
        }
        return $disponiblePartida;

    }
    function agrearUsuario($idPartida,$idUsuario){
        $sql = "INSERT INTO partida_usuarios ( partida_id, usuario_id, turno) VALUES ($idPartida, $idUsuario,'0')";
        $usuarioAgregado = ExQy($sql);
        return $usuarioAgregado;
    }

    function crearUsuario($nombre){
        
        $sql = "SELECT * FROM usuarios WHERE nombre = '$nombre'";
        $usuarioEncontrado = ExQy( $sql );
        if ( $usuarioEncontrado ) {            
            return $usuarioEncontrado[0]['id'];
        }else{
    
            $sql = "INSERT INTO usuarios (nombre) VALUES ('$nombre')";
            $usuarioAgregado = ExQy($sql);
            $sql = 'SELECT LAST_INSERT_ID() as idUsuario';
            $usuarioAgregado = ExQy($sql);
            
            return $usuarioAgregado[0]['idUsuario'];

        }

    }

    function ObtenFichasDelPozo($partida_id) {
        $sql = 'SELECT * FROM partida_ficha WHERE partida_id='.$partida_id.' AND disponible=1 AND partida_usuario_id IS NULL ORDER BY RAND()';
        $fichasDelPozo = ExQy($sql);
        return $fichasDelPozo;
    }
    function AsignaFichas($partida_id,$usuario_id, $numeroFichas = 6) {
        $contador =0;
        $fichasDelPozo = ObtenFichasDelPozo($partida_id);
        foreach ($fichasDelPozo as $fichaDelPozo) {
            if ($contador == $numeroFichas) {
                break;
            }
            $sql = 'SELECT id FROM partida_usuarios WHERE partida_id='.$partida_id.'  AND usuario_id='.$usuario_id;
            $partidas_usuarios = ExQy($sql);
            if (!empty($partidas_usuarios)) {
                $partidas_usuarios = $partidas_usuarios[0];
                $sql = 'UPDATE partida_ficha SET partida_usuario_id='.$partidas_usuarios['id'].' WHERE id='.$fichaDelPozo['id'];
                $resultado = insert($sql);
                $contador++;
            }
        }
        $fichasDeUsuario = obtenFichasDeUsuario($partida_id,$usuario_id);
        return $fichasDeUsuario;
    }
    function obtenFichasDeUsuario($partida_id,$usuario_id)
    {
        $sql = 'SELECT partida_ficha.*,fichas.numero1,fichas.numero2 FROM partida_ficha 
            INNER JOIN partida_usuarios ON partida_usuarios.id=partida_ficha.partida_usuario_id 
            INNER JOIN fichas ON fichas.id=partida_ficha.ficha_id 
            WHERE partida_usuarios.usuario_id='.$usuario_id.' AND partida_usuarios.partida_id='.$partida_id;
        $resultado = ExQy($sql);
        // echo var_dump($resultado);
        return json_encode($resultado);
    }

    function jugadoresCompletos($idPartida){
        $sql = "SELECT COUNT(*) as total FROM partida_usuarios WHERE partida_id = $idPartida";
        $totalUsuarios = ExQy($sql);
        $sql = "SELECT * FROM  partidas WHERE id = $idPartida";
        $partida = ExQy($sql);
        if($totalUsuarios[0]['total'] == $partida[0]['numero_jugadores'] ){
            $sql = "UPDATE partidas SET Estado = 2 WHERE id = $idPartida";
            $guardado = insert($sql);
            return true;
        }
        return false;
    }

    function obtenLugaresDisponibles($idPartida)
    {
        $sql1 = 'SELECT * FROM posiciones_tablero WHERE partidas_id='.$idPartida.' AND disponible=1';
        // echo $sql1;
        $lugaresDisponibles = ExQy($sql1);
        // echo var_dump($lugaresDisponibles);
        return $lugaresDisponibles;
    }
    function crearTablero($idPartida){
        // echo $idPartida;
        for($i=0;$i<31;$i++){
            for($j=0;$j<21;$j++){
                $sql= "INSERT INTO posiciones_tablero (partidas_id, posicion_x, posicion_y, numero, disponible) 
                VALUES ($idPartida, $i, $j, '7', '0')";                
                // echo $sql . '<br>';
                $resultado = insert($sql);
            }

        }
        crearFichasPartida($idPartida);

    }
    function crearFichasPartida($idPartida){
        $sql = "SELECT * FROM fichas";
        $fichas = ExQy($sql);
        foreach ($fichas as $data) {
            $sql = "INSERT INTO partida_ficha (partida_id, ficha_id, partida_usuario_id, disponible) 
            VALUES (".$idPartida.", ".$data['id'].", NULL, '1')";
            // echo $sql;
            $partida = ExQy($sql);
        }
    }
    function obtenLugaresPermitidos($partida_id, $usuario_id, $partida_ficha_id,$esjson = true)
    {
        $lugaresDisponibles = obtenLugaresDisponibles($partida_id);
        $lugaresPermitidos = array();

        if (count($lugaresDisponibles)>0) {
            $sql = 'SELECT fichas.numero1,fichas.numero2 FROM partida_ficha INNER JOIN fichas ON fichas.id=partida_ficha.ficha_id WHERE partida_ficha.id='.$partida_ficha_id;
            $numerosFicha = ExQy($sql);
            $numerosFicha = $numerosFicha[0];
            // echo var_dump($lugaresDisponibles);
            foreach ($lugaresDisponibles as $lugarDisponible) {

                if ($lugarDisponible['numero']==$numerosFicha['numero1'] || $lugarDisponible['numero']==$numerosFicha['numero2']) {
                    $lugaresPermitidos[$lugarDisponible['id']] = $lugarDisponible['numero'];
                }
            }
        }
        else {
            $posicion = obtenPosicionTableroXY($partida_id,15,11);
            $posicion2 = obtenPosicionTableroXY($partida_id,16,11);
            
            $sql = 'SELECT numero1,numero2 FROM fichas 
                INNER JOIN partida_ficha ON partida_ficha.ficha_id=fichas.id
                WHERE partida_ficha.id='.$partida_ficha_id;
            $miFicha = ExQy($sql);
            $miFicha = $miFicha[0];
            
            

            $sql = 'UPDATE posiciones_tablero SET numero='.$miFicha['numero1'].',disponible=1 WHERE id='.$posicion['id'];
            insert($sql);
            $sql = 'UPDATE posiciones_tablero SET numero='.$miFicha['numero2'].',disponible=1 WHERE id='.$posicion2['id'];
            
            insert($sql);
        }   
        // echo var_dump($numerosFicha);
        return  $esjson ?  json_encode($lugaresPermitidos): $lugaresPermitidos ;

    }


    function obtenPosicionTableroXY($partida_id, $x, $y){
        $sql15 = 'SELECT * FROM posiciones_tablero WHERE partidas_id='.$partida_id.' AND posicion_x='.$x.' AND posicion_y='.$y;
        // echo $sql15;
        $posicionesTablero = ExQy($sql15);
        return $posicionesTablero[0];
    }

    function lugaresATirar($posicionTableroId, $partida_id)
    {
        $sql = 'SELECT * FROM posiciones_tablero WHERE id='.$posicionTableroId;
        $posicionTablero = ExQy($sql);
        // echo var_dump($posicionTablero);
        $posicionX = (int)$posicionTablero[0]['posicion_x'];
        $posicionYo = (int)$posicionTablero[0]['posicion_y'];
                    // echo '<br>'.__LINE__.'<br>';
        $posicionesATirar = array();
        $contador = 0;
        if ($posicionX>1){
            // echo $posicionYo.'<br>';

            $posicion = obtenPosicionTableroXY($partida_id ,$posicionX-1,$posicionYo);
            // echo '<br>'.__LINE__.'<br>';
            if ($posicion['numero']==7) {
                $posicion2 = obtenPosicionTableroXY($partida_id ,$posicionX-2,$posicionYo);
                $posicionesATirar[$contador]['numero1'] = $posicion;
                $posicionesATirar[$contador]['numero2'] = $posicion2;
                $contador++;
            }
        }
        if ($posicionX<29){
            $posicion = obtenPosicionTableroXY($partida_id ,$posicionX+1,$posicionYo);
            // echo '<br>'.__LINE__.'<br>';

            if ($posicion['numero']==7) {
                $posicion2 = obtenPosicionTableroXY($partida_id ,$posicionX+2,$posicionYo);
                $posicionesATirar[$contador]['numero1'] = $posicion;
                $posicionesATirar[$contador]['numero2'] = $posicion2;
                $contador++;
            }
        }
        if ($posicionYo>1){
            $posicion = obtenPosicionTableroXY($partida_id ,$posicionX, $posicionYo-1);
            // echo '<br>'.__LINE__.'<br>';

            if ($posicion['numero']==7) {
                $posicion2 = obtenPosicionTableroXY($partida_id ,$posicionX, $posicionYo-2);
                $posicionesATirar[$contador]['numero1'] = $posicion;
                $posicionesATirar[$contador]['numero2'] = $posicion2;
                $contador++;
            }
        }
        if ($posicionY<19){
            $posicion = obtenPosicionTableroXY($partida_id ,$posicionX, $posicionYo+1);
            if ($posicion['numero']==7) {
                $posicion2 = obtenPosicionTableroXY($partida_id ,$posicionX, $posicionYo+2);
                $posicionesATirar[$contador]['numero1'] = $posicion;
                $posicionesATirar[$contador]['numero2'] = $posicion2;
                $contador++;
            }
        }
        return $posicionesATirar;
    }

    function tiraFicha($posicionTableroId, $partida_id, $usuario_id, $partida_ficha_id)
     {
        $lugaresPermitidos = obtenLugaresPermitidos($partida_id, $usuario_id, $partida_ficha_id,false);
        $lugaresPermitidos=$lugaresPermitidos;
        // echo var_dump($lugaresPermitidos);
        $resultado = array();
        if (!empty($lugaresPermitidos) && isset($lugaresPermitidos[$posicionTableroId])) {
            // echo 'hay lugares permitidos';
            $lugaresATirar = lugaresATirar($posicionTableroId,$partida_id);
            $lugarATirar = $lugaresATirar[0];
            // echo var_dump($lugarATirar);

            $sql = 'SELECT * FROM posiciones_tablero WHERE id='.$posicionTableroId;
            $posicionAJugar = ExQy($sql);
            $posicionAJugar = $posicionAJugar[0];

            $x = $posicionAJugar['posicion_x'];
            $y = $posicionAJugar['posicion_y'];
            $numeroAJugar = $posicionAJugar['numero'];
            

            $sql = 'SELECT numero1,numero2 FROM fichas 
                INNER JOIN partida_ficha ON partida_ficha.ficha_id=fichas.id
                WHERE partida_ficha.id='.$partida_ficha_id;
            $miFicha = ExQy($sql);
            $miFicha = $miFicha[0];
            $idA = 0;
            $idB = 0;
            if ($miFicha['numero1']==$numeroAJugar) {
                $numeroATirar = $miFicha['numero1'];
                $numeroATirar2 = $miFicha['numero2'];
                $idA = $lugarATirar['numero1']['id'];
                $idB = $lugarATirar['numero2']['id'];
                // $idA = ;
            }
            if ($miFicha['numero2']==$numeroAJugar) {
                $numeroATirar = $miFicha['numero2'];
                $numeroATirar2 = $miFicha['numero1'];
                $idA = $lugarATirar['numero1']['id'];
                $idB = $lugarATirar['numero2']['id'];
            }
            if ($lugarATirar['numero1']['numero']==$numeroAJugar) {
            }
            if ($lugarATirar['numero2']['numero']==$numeroAJugar) {
            }
            $sql = 'UPDATE posiciones_tablero SET disponible=0 WHERE partidas_id='.$partida_id;
            insert($sql);
            $sql1 = 'UPDATE posiciones_tablero SET numero='.$numeroATirar.',disponible=0 WHERE id='.$idA;
            // echo $sql1;
            insert($sql1);
            $sql14 = 'UPDATE posiciones_tablero SET numero='.$numeroATirar2.',disponible=1 WHERE id='.$idB;
            // echo $sql14;

            insert($sql14);

        }
        return json_encode($resultado);
        // return true;
    }

    function gana($usuario_id,$partida_id)
    {
        // $sql = 'SELECT disponible FROM partida_usuarios INNER JOIN partida_ficha WHERE partida_usuarios.usuario_id='.$idUsuario;
        // $sql = 'SELECT disponible FROM partida_usuarios INNER JOIN partida_ficha WHERE partida_usuarios.usuario_id='.$idUsuario;
         $sql = 'SELECT partida_ficha.*,fichas.numero1,fichas.numero2 FROM partida_ficha 
            INNER JOIN partida_usuarios ON partida_usuarios.id=partida_ficha.partida_usuario_id 
            INNER JOIN fichas ON fichas.id=partida_ficha.ficha_id 
            WHERE partida_usuarios.usuario_id='.$usuario_id.' AND partida_usuarios.partida_id='.$partida_id.' AND partida_ficha.disponible=1';
        $fichas = ExQy($sql);
        foreach ($fichas as $ficha) {
            if($ficha['disponible']==1) {
                return false;
            }
        }
        return true;
    }

    function posicionesDelTablero()
    {
        $idPartida = $_SESSION['idPartida'];
        $sql = 'SELECT partidas_id, posicion_x, posicion_y, numero FROM posiciones_tablero 
                WHERE partidas_id='.$idPartida;
        $posiciones = ExQy($sql);
        return json_encode($posiciones);
    }
    function esMiTurno($idUsuario,$idPartida){
        $sql = "SELECT * FROM  partida_usuarios WHERE usuario_id = $idUsuario";
        $turno = ExQy($sql);
        $turno = $turno[0];
        $ganador = gana($idUsuario,$idPartida);
        if($ganador == true){
            $sql = "UPDATE partidas SET Estado = 0 WHERE id = $idPartida ";
            $res = ExQy($sql);
            return 2;
        }
        if($turno['turno'] == 1){
            $tirar = 1;
        }else{
            $tirar = 0;
        }
        return $tirar;
    }
    function borrarPartida(){
        $sql = "UPDATE partidas SET Estado = 0";
        $res = ExQy($sql);
    }
    function partidaActiva($idPartida){
        $sql = "SELECT * FROM partidas WHERE id = $idPartida";
        $partida = ExQy($sql);
        $partida = $partida[0];
        if($partida['Estado'] == 1 || $partida['Estado'] == 2){
            return true;
        }
        return false;
    }

?>