<?php
include('conexion.php');
$sql = "SELECT * FROM fichas";
$fichas = ExQy($sql);
echo '<pre>';
print_r($fichas);
echo '</pre>';


?>