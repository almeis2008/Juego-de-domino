<html>
<head>
	<title>Acceso</title>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
	<script src="http://code.jquery.com/jquery-2.1.1.js" type="text/javascript"></script>
</head>
<body style="background-color: rgb(221, 225, 255);">

<?php 
include dirname(__FILE__) . '/../domino.php';

// ini_set('display_errors', 1);

	if ( isset($_REQUEST['partida']) ) {

		if ( $_REQUEST['partida'] == 'crear' ) {
			// echo 'crear la partida';			
			$idUsuario = crearUsuario( $_REQUEST['usuario'] );
			PartidaNueva( $_REQUEST['njugadores'] );
			$idPartida = PartidaDisponible();
		
			agrearUsuario( $idPartida, $idUsuario );
			crearTablero( $idPartida );
			$sql = 'UPDATE partida_usuarios Set Turno = 1 WHERE usuario_id = ' . $idUsuario;
			insert( $sql );

		}else if( $_REQUEST['partida'] == 'unirse' ) {
			// unirse a la partida
			$idUsuario = crearUsuario( $_REQUEST['usuario'] );
			
			$idPartida = PartidaDisponible();
			agrearUsuario( $idPartida, $idUsuario );
		}
		
		// En session el usuario y la partida
		$_SESSION['idUsuario'] = $idUsuario;
		$_SESSION['idPartida'] = $idPartida;

	    AsignaFichas($idPartida, $idUsuario, $numeroFichas = 6);

		// Redirect al tablero
		// echo 'redirect al tablero';
		?>

		<div style="color:green; font-size:27px;"><?php echo $_REQUEST['usuario'] ?>
			<span id="miturno"></span>
		</div>
		
		<div> <?php echo '<pre>'; print_r($_SESSION); echo '</pre>'; ?> </div>

			<script type="text/javascript">
				setInterval(function(){ $.get('http://192.168.5.109/domino/domino.php?esMiTurno=1', function(data){
					
					if ( data == 1 ) {
						mensajeturno = '<span style="color:green;"> Es tu turno </span>';
					}else if ( data == 2 ){
						mensajeturno = '<span style="color:green;"> Ganaste </span>';
						mensajegana = '<div style="width: 100%;height: 100%;position: fixed;z-index: 2;background-color: rgba(0, 71, 255, 0.35);text-align: center;vertical-align: middle;color: white;" onclick="javascript:window.location.href="http://192.168.5.109/domino/interface/login.php">Fin, click para salir</div>';
						$("body").after(mensajegana);

					}else{
						mensajeturno = '<span style="color:red;"> No es tu turno </span>';
					}
					// console.log( data );

					$("#miturno").html(mensajeturno);
				}) },3000);
			</script>

		<button id="terminar">Terminar</button>
		<script type="text/javascript">
			$("#terminar").click(function(){
				$.post('http://192.168.5.109/domino/domino.php?borrarPartida=1');
				window.location.href="http://192.168.5.109/domino/interface/login.php"
			})
		</script>

		<iframe src="http://192.168.5.109/domino/" width="100%" height="100%"></iframe>

		<?php
		// header('Location: http://192.168.5.109/domino/interface/login.php');

		exit();

	}

	// var_dump($_REQUEST);
?>

<?php 

// conectarse a la bd, ver si hay partida creada
$partidaEnCurso = PartidaDisponible();

if ( $partidaEnCurso ) { 
	// Si ya estan los usuarios completos que ya no deje unirse
	if ( jugadoresCompletos($partidaEnCurso) ) {

		echo 'La partida ya se esta jugando, vuelve mas tarde';
		exit();
	}

	?>

	<div style="text-align:center;">
		<form>
			<div style="color:orange; font-size:27px;"> Unirse a la partida </div>			
			<div> Ingresa tu usuario </div>
			<div> <input type="text" name="usuario" class="form-control" style="width: 50%;margin-left: 25%;"> </div>
			<input type="hidden" name="partida" value="unirse">
			<div> <button class="btn btn-success" type="submit">Unirse</button> </div>
		</form>
	</div>


<? }else{ ?>

		<div style="text-align:center;">
		<form>
			<div style="color:green; font-size:27px;"> Crear partida nueva </div>
			<div> Ingresa tu usuario </div>
			<div> <input type="text" name="usuario" class="form-control" style="width: 50%;margin-left: 25%;"> </div>
			<input type="hidden" name="partida" value="crear">			

			<div> 
				<div>Numero de jugadores</div>
				<div>
				<select name="njugadores" class="form-control" style="width: 50%;margin-left: 25%;">
					<option>2</option>
					<option>3</option>
					<option>4</option>
				</select>
				</div>
			</div>
			<div> <button class="btn btn-primary" type="submit">Crear</button> </div>
		</form>
	</div>

<?php } ?>


</body>
</html>